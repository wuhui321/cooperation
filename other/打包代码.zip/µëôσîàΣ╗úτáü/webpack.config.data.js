module.exports = {
    title: '点击探索，给宝宝___的第一口',
    shareTitle: '点击探索，给宝宝___的第一口',
    shareDesc: '抢先感受嘉宝农场亲临视觉，参与探索开启红包大抽奖！',
    shareUrl: 'http://m.letlike.com/case/2018/gerber/farmvr/testv1/20180331/app.html',
    shareImg: 'http://s.letlike.com/2018/gerber/farmvr/extra/share.jpg'
};